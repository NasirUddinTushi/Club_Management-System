<?php 
header('Location:../homepage/');

 ?>