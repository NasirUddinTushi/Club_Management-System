<footer>
	<nav class="footer">
		<ul>
			<li><a href="">Contact</a></li>
			<li><a href="">Social</a></li>
			<li><a href="">Associates</a></li>
			<li><a href="">Documents</a></li>
			<li><a href="">Faculty</a></li>
		</ul>
	</nav>
</footer>
<div class="footer-bottom"></div>