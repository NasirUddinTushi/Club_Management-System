<div class="image_container">
<form action="server.php" method="GET" enctype="multipart/form-data">
		<fieldset>	
		<?php include 'igl.php'; ?>
		</fieldset>
		
	</form>
</div>

<style type="text/css">



	
	.image_container{
	position: relative;
	left:20%;
	right:22%;
	top:25%;
	margin-bottom: 20%;
	width: 800px;
	background-color: rgba(179, 179, 179,0.4);/*;*/
	padding: 2% 2%;
	}


</style>