<head>
	<title>AIUB Club</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Ubuntu">
	<link rel="stylesheet" type="text/css" href="../css/homepage.css">
	<link rel="stylesheet" type="text/css" href="../font-awesome/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="../css/slide.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 
   <!-- Including our scripting file. -->

</head>
</head>